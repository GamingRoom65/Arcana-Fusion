
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sadnightfury.arcana.fusion.init;

import net.sadnightfury.arcana.fusion.ArcanafusionMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleType;

public class ArcanafusionModParticleTypes {
	public static final DeferredRegister<ParticleType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, ArcanafusionMod.MODID);
	public static final RegistryObject<SimpleParticleType> CODE_ERASER_BEAM_PARTICLE = REGISTRY.register("code_eraser_beam_particle", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> ARCANE_ERASER_BEAM_PARTICLE = REGISTRY.register("arcane_eraser_beam_particle", () -> new SimpleParticleType(true));
}
