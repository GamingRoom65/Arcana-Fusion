
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sadnightfury.arcana.fusion.init;

import net.sadnightfury.arcana.fusion.entity.DBEEntity;
import net.sadnightfury.arcana.fusion.ArcanafusionMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ArcanafusionModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ArcanafusionMod.MODID);
	public static final RegistryObject<EntityType<DBEEntity>> DBE = register("projectile_dbe",
			EntityType.Builder.<DBEEntity>of(DBEEntity::new, MobCategory.MISC).setCustomClientFactory(DBEEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}
}
