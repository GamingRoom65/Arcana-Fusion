
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sadnightfury.arcana.fusion.init;

import net.sadnightfury.arcana.fusion.client.particle.CodeEraserBeamParticleParticle;
import net.sadnightfury.arcana.fusion.client.particle.ArcaneEraserBeamParticleParticle;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.api.distmarker.Dist;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ArcanafusionModParticles {
	@SubscribeEvent
	public static void registerParticles(RegisterParticleProvidersEvent event) {
		event.registerSpriteSet(ArcanafusionModParticleTypes.CODE_ERASER_BEAM_PARTICLE.get(), CodeEraserBeamParticleParticle::provider);
		event.registerSpriteSet(ArcanafusionModParticleTypes.ARCANE_ERASER_BEAM_PARTICLE.get(), ArcaneEraserBeamParticleParticle::provider);
	}
}
