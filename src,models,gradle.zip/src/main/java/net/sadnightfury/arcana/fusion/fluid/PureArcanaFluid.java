
package net.sadnightfury.arcana.fusion.fluid;

import net.sadnightfury.arcana.fusion.init.ArcanafusionModItems;
import net.sadnightfury.arcana.fusion.init.ArcanafusionModFluids;
import net.sadnightfury.arcana.fusion.init.ArcanafusionModFluidTypes;
import net.sadnightfury.arcana.fusion.init.ArcanafusionModBlocks;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

public abstract class PureArcanaFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> ArcanafusionModFluidTypes.PURE_ARCANA_TYPE.get(), () -> ArcanafusionModFluids.PURE_ARCANA.get(),
			() -> ArcanafusionModFluids.FLOWING_PURE_ARCANA.get()).explosionResistance(132f).slopeFindDistance(8).bucket(() -> ArcanafusionModItems.PURE_ARCANA_BUCKET.get()).block(() -> (LiquidBlock) ArcanafusionModBlocks.PURE_ARCANA.get());

	private PureArcanaFluid() {
		super(PROPERTIES);
	}

	public static class Source extends PureArcanaFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends PureArcanaFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
