
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sadnightfury.arcana.fusion.init;

import net.sadnightfury.arcana.fusion.block.PureUltimateEssenceBlock;
import net.sadnightfury.arcana.fusion.block.PureTechEssenceBlock;
import net.sadnightfury.arcana.fusion.block.PureMultiversalEssenceBlock;
import net.sadnightfury.arcana.fusion.block.PureArcanaBlock;
import net.sadnightfury.arcana.fusion.ArcanafusionMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

public class ArcanafusionModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, ArcanafusionMod.MODID);
	public static final RegistryObject<Block> PURE_TECH_ESSENCE = REGISTRY.register("pure_tech_essence", () -> new PureTechEssenceBlock());
	public static final RegistryObject<Block> PURE_ARCANA = REGISTRY.register("pure_arcana", () -> new PureArcanaBlock());
	public static final RegistryObject<Block> PURE_MULTIVERSAL_ESSENCE = REGISTRY.register("pure_multiversal_essence", () -> new PureMultiversalEssenceBlock());
	public static final RegistryObject<Block> PURE_ULTIMATE_ESSENCE = REGISTRY.register("pure_ultimate_essence", () -> new PureUltimateEssenceBlock());
}
