
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.sadnightfury.arcana.fusion.init;

import net.sadnightfury.arcana.fusion.fluid.types.PureUltimateEssenceFluidType;
import net.sadnightfury.arcana.fusion.fluid.types.PureTechEssenceFluidType;
import net.sadnightfury.arcana.fusion.fluid.types.PureMultiversalEssenceFluidType;
import net.sadnightfury.arcana.fusion.fluid.types.PureArcanaFluidType;
import net.sadnightfury.arcana.fusion.ArcanafusionMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fluids.FluidType;

public class ArcanafusionModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES, ArcanafusionMod.MODID);
	public static final RegistryObject<FluidType> PURE_TECH_ESSENCE_TYPE = REGISTRY.register("pure_tech_essence", () -> new PureTechEssenceFluidType());
	public static final RegistryObject<FluidType> PURE_ARCANA_TYPE = REGISTRY.register("pure_arcana", () -> new PureArcanaFluidType());
	public static final RegistryObject<FluidType> PURE_MULTIVERSAL_ESSENCE_TYPE = REGISTRY.register("pure_multiversal_essence", () -> new PureMultiversalEssenceFluidType());
	public static final RegistryObject<FluidType> PURE_ULTIMATE_ESSENCE_TYPE = REGISTRY.register("pure_ultimate_essence", () -> new PureUltimateEssenceFluidType());
}
