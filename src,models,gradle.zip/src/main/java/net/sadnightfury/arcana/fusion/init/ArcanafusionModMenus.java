
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.sadnightfury.arcana.fusion.init;

import net.sadnightfury.arcana.fusion.world.inventory.ATGBG1MAINMenu;
import net.sadnightfury.arcana.fusion.ArcanafusionMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

public class ArcanafusionModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, ArcanafusionMod.MODID);
	public static final RegistryObject<MenuType<ATGBG1MAINMenu>> ATGBG_1_MAIN = REGISTRY.register("atgbg_1_main", () -> IForgeMenuType.create(ATGBG1MAINMenu::new));
}
