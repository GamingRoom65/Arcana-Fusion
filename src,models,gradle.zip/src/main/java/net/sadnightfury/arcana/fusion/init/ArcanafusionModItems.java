
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sadnightfury.arcana.fusion.init;

import net.sadnightfury.arcana.fusion.item.PureUltimateEssenceItem;
import net.sadnightfury.arcana.fusion.item.PureTechEssenceItem;
import net.sadnightfury.arcana.fusion.item.PureMultiversalEssenceItem;
import net.sadnightfury.arcana.fusion.item.PureArcanaItem;
import net.sadnightfury.arcana.fusion.item.HeavenlyFlareItem;
import net.sadnightfury.arcana.fusion.item.DevBrickItem;
import net.sadnightfury.arcana.fusion.item.CodeEraserItem;
import net.sadnightfury.arcana.fusion.item.CEUItem;
import net.sadnightfury.arcana.fusion.item.CEAItem;
import net.sadnightfury.arcana.fusion.item.ArcaneTechGuideBookItem;
import net.sadnightfury.arcana.fusion.item.ArcaneEraserItem;
import net.sadnightfury.arcana.fusion.item.AEUItem;
import net.sadnightfury.arcana.fusion.item.AEAItem;
import net.sadnightfury.arcana.fusion.ArcanafusionMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

public class ArcanafusionModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, ArcanafusionMod.MODID);
	public static final RegistryObject<Item> PURE_TECH_ESSENCE_BUCKET = REGISTRY.register("pure_tech_essence_bucket", () -> new PureTechEssenceItem());
	public static final RegistryObject<Item> PURE_ARCANA_BUCKET = REGISTRY.register("pure_arcana_bucket", () -> new PureArcanaItem());
	public static final RegistryObject<Item> PURE_MULTIVERSAL_ESSENCE_BUCKET = REGISTRY.register("pure_multiversal_essence_bucket", () -> new PureMultiversalEssenceItem());
	public static final RegistryObject<Item> PURE_ULTIMATE_ESSENCE_BUCKET = REGISTRY.register("pure_ultimate_essence_bucket", () -> new PureUltimateEssenceItem());
	public static final RegistryObject<Item> TEST_ITEM = REGISTRY.register("test_item", () -> new CodeEraserItem());
	public static final RegistryObject<Item> AEA = REGISTRY.register("aea", () -> new AEAItem());
	public static final RegistryObject<Item> AEU = REGISTRY.register("aeu", () -> new AEUItem());
	public static final RegistryObject<Item> CEA = REGISTRY.register("cea", () -> new CEAItem());
	public static final RegistryObject<Item> CEU = REGISTRY.register("ceu", () -> new CEUItem());
	public static final RegistryObject<Item> ARCANE_TECH_GUIDE_BOOK = REGISTRY.register("arcane_tech_guide_book", () -> new ArcaneTechGuideBookItem());
	public static final RegistryObject<Item> ARCANE_ERASER = REGISTRY.register("arcane_eraser", () -> new ArcaneEraserItem());
	public static final RegistryObject<Item> HEAVENLY_FLARE = REGISTRY.register("heavenly_flare", () -> new HeavenlyFlareItem());
	public static final RegistryObject<Item> DEV_BRICK = REGISTRY.register("dev_brick", () -> new DevBrickItem());
}
