
package net.sadnightfury.arcana.fusion.fluid;

import net.sadnightfury.arcana.fusion.init.ArcanafusionModItems;
import net.sadnightfury.arcana.fusion.init.ArcanafusionModFluids;
import net.sadnightfury.arcana.fusion.init.ArcanafusionModFluidTypes;
import net.sadnightfury.arcana.fusion.init.ArcanafusionModBlocks;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

public abstract class PureUltimateEssenceFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> ArcanafusionModFluidTypes.PURE_ULTIMATE_ESSENCE_TYPE.get(), () -> ArcanafusionModFluids.PURE_ULTIMATE_ESSENCE.get(),
			() -> ArcanafusionModFluids.FLOWING_PURE_ULTIMATE_ESSENCE.get()).explosionResistance(132f).slopeFindDistance(8).bucket(() -> ArcanafusionModItems.PURE_ULTIMATE_ESSENCE_BUCKET.get())
			.block(() -> (LiquidBlock) ArcanafusionModBlocks.PURE_ULTIMATE_ESSENCE.get());

	private PureUltimateEssenceFluid() {
		super(PROPERTIES);
	}

	public static class Source extends PureUltimateEssenceFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends PureUltimateEssenceFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
