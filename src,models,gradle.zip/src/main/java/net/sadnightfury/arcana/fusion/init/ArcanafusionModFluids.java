
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.sadnightfury.arcana.fusion.init;

import net.sadnightfury.arcana.fusion.fluid.PureUltimateEssenceFluid;
import net.sadnightfury.arcana.fusion.fluid.PureTechEssenceFluid;
import net.sadnightfury.arcana.fusion.fluid.PureMultiversalEssenceFluid;
import net.sadnightfury.arcana.fusion.fluid.PureArcanaFluid;
import net.sadnightfury.arcana.fusion.ArcanafusionMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

public class ArcanafusionModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(ForgeRegistries.FLUIDS, ArcanafusionMod.MODID);
	public static final RegistryObject<FlowingFluid> PURE_TECH_ESSENCE = REGISTRY.register("pure_tech_essence", () -> new PureTechEssenceFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_PURE_TECH_ESSENCE = REGISTRY.register("flowing_pure_tech_essence", () -> new PureTechEssenceFluid.Flowing());
	public static final RegistryObject<FlowingFluid> PURE_ARCANA = REGISTRY.register("pure_arcana", () -> new PureArcanaFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_PURE_ARCANA = REGISTRY.register("flowing_pure_arcana", () -> new PureArcanaFluid.Flowing());
	public static final RegistryObject<FlowingFluid> PURE_MULTIVERSAL_ESSENCE = REGISTRY.register("pure_multiversal_essence", () -> new PureMultiversalEssenceFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_PURE_MULTIVERSAL_ESSENCE = REGISTRY.register("flowing_pure_multiversal_essence", () -> new PureMultiversalEssenceFluid.Flowing());
	public static final RegistryObject<FlowingFluid> PURE_ULTIMATE_ESSENCE = REGISTRY.register("pure_ultimate_essence", () -> new PureUltimateEssenceFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_PURE_ULTIMATE_ESSENCE = REGISTRY.register("flowing_pure_ultimate_essence", () -> new PureUltimateEssenceFluid.Flowing());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(PURE_TECH_ESSENCE.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_PURE_TECH_ESSENCE.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(PURE_ARCANA.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_PURE_ARCANA.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(PURE_MULTIVERSAL_ESSENCE.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_PURE_MULTIVERSAL_ESSENCE.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(PURE_ULTIMATE_ESSENCE.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_PURE_ULTIMATE_ESSENCE.get(), RenderType.translucent());
		}
	}
}
