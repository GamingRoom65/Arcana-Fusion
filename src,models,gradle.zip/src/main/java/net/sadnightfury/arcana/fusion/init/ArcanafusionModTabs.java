
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.sadnightfury.arcana.fusion.init;

import net.sadnightfury.arcana.fusion.ArcanafusionMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

public class ArcanafusionModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ArcanafusionMod.MODID);
	public static final RegistryObject<CreativeModeTab> ARCANA_FUSION = REGISTRY.register("arcana_fusion",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.arcanafusion.arcana_fusion")).icon(() -> new ItemStack(Items.AMETHYST_SHARD)).displayItems((parameters, tabData) -> {
				tabData.accept(ArcanafusionModItems.TEST_ITEM.get());
				tabData.accept(ArcanafusionModItems.AEA.get());
				tabData.accept(ArcanafusionModItems.AEU.get());
				tabData.accept(ArcanafusionModItems.CEA.get());
				tabData.accept(ArcanafusionModItems.CEU.get());
				tabData.accept(ArcanafusionModItems.ARCANE_TECH_GUIDE_BOOK.get());
				tabData.accept(ArcanafusionModItems.ARCANE_ERASER.get());
				tabData.accept(ArcanafusionModItems.HEAVENLY_FLARE.get());
				tabData.accept(ArcanafusionModItems.DEV_BRICK.get());
			}).withSearchBar().build());
}
